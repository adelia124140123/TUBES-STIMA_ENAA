using System;
using System.Drawing;
using Robocode.TankRoyale.BotApi;
using Robocode.TankRoyale.BotApi.Events;
using System.IO;
using Microsoft.Extensions.Configuration;

public class ENAA_Nemesis : Bot
{
    // penanda apakah bot lagi punya target atau belum. 
    private bool _hasTarget = false;

    // nyimpen posisi terakhir target
    private double _targetX;
    private double _targetY;

    // nyimpen id musuh yang lagi di-lock
    private int _lockedBotId = -1;

    // nyimpen turn terakhir musuh terdeteksi radar
    private int _lastScannedTurn = -1;

    // batas maksimal target hilang sebelum dianggap lost
    private const int LOST_TARGET_TIMEOUT = 10; 

    static void Main(string[] args)
    {
        // load konfigurasi bot dari file json
        var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("ENAA_Nemesis.json");

        var config = builder.Build();

        // ambil info bot dari konfigurasi
        var botInfo = BotInfo.FromConfiguration(config);

        // jalankan bot
        new ENAA_Nemesis(botInfo).Start();
    }

    // constructor bot
    private ENAA_Nemesis(BotInfo botInfo) : base(botInfo) { }

    public override void Run()
    {
        // ngatur warna tiap bagian bot biar estetik dulu bosku
        BodyColor   = Color.FromArgb(0xFF, 0xC2, 0x18, 0x5B); 
        TurretColor = Color.FromArgb(0xFF, 0x8B, 0x00, 0x38); 
        RadarColor  = Color.FromArgb(0xFF, 0xF0, 0x62, 0x92); 
        ScanColor   = Color.FromArgb(0xFF, 0xFF, 0x14, 0x93); 
        BulletColor = Color.FromArgb(0xFF, 0x3D, 0x0B, 0x1F); 
        TracksColor = Color.FromArgb(0xFF, 0x88, 0x00, 0x33); 
        GunColor    = Color.FromArgb(0xFF, 0xAD, 0x14, 0x57); 

        // loop utama bot selama game masih berjalan
        while (IsRunning)
        {
            // bot belok dikit terus biar gerak melingkar
            SetTurnLeft(1.7);

            // batas kecepatan maksimum
            MaxSpeed = 6;

            // maju terus jauh banget biar jalan nonstop
            SetForward(10_000);

            // ngecek apakah target udah terlalu lama ga ke-scan
            bool targetLost = _hasTarget &&
                              (_lastScannedTurn < 0 ||
                               TurnNumber - _lastScannedTurn > LOST_TARGET_TIMEOUT);

            // kalau target hilang
            if (targetLost)
            {
                // reset semua data target
                _hasTarget = false;
                _lockedBotId = -1;
                _lastScannedTurn = -1;

                // radar muter full nyari target baru
                SetTurnRadarLeft(360);
            }

            // kalau belum punya target dari awal
            else if (!_hasTarget)
            {
                // radar muter nyari musuh
                SetTurnRadarLeft(360);
            }

            // eksekusi semua perintah gerakan
            Go();
        }
    }

    public override void OnScannedBot(ScannedBotEvent e)
    {
        // kalau belum punya target, lock musuh pertama yang ketemu
        if (!_hasTarget)
        {
            _hasTarget = true;
            _lockedBotId = e.ScannedBotId;
        }

        // abaikan musuh lain selain yang lagi di-lock
        if (e.ScannedBotId != _lockedBotId) return;

        // update turn terakhir target terdeteksi
        _lastScannedTurn = TurnNumber;

        // update posisi target
        _targetX = e.X;
        _targetY = e.Y;

        // hitung arah radar ke target
        double radarBearing = RadarBearingTo(e.X, e.Y);

        // radar diputar lebih besar biar tracking ga gampang lepas
        SetTurnRadarLeft(radarBearing * 1.5);

        // hitung power peluru berdasarkan jarak musuh
        double firePower   = CalcFirePower(DistanceTo(e.X, e.Y));

        // rumus kecepatan peluru
        double bulletSpeed = 20 - (3 * firePower);

        // estimasi waktu peluru sampai ke target
        double ticks       = DistanceTo(e.X, e.Y) / bulletSpeed;

        // prediksi posisi X musuh saat peluru sampai
        double predictedX = e.X + Math.Sin(ToRad(e.Direction)) * e.Speed * ticks;

        // prediksi posisi Y musuh saat peluru sampai
        double predictedY = e.Y + Math.Cos(ToRad(e.Direction)) * e.Speed * ticks;

        // arah turret ke posisi prediksi musuh
        double gunBearing = GunBearingTo(predictedX, predictedY);

        // putar turret ke target prediksi
        SetTurnGunLeft(gunBearing);

        // nembak kalau arah turret udah cukup akurat dan gun ga panas
        if (Math.Abs(gunBearing) <= 15 && GunHeat == 0)
            Fire(firePower);
    }

    public override void OnBotDeath(BotDeathEvent e)
    {
        // kalau target yang di-lock mati
        if (e.VictimId == _lockedBotId)
        {
            // reset data target
            _hasTarget = false;
            _lockedBotId = -1;
            _lastScannedTurn = -1;
        }
    }

    public override void OnHitByBullet(HitByBulletEvent e)
    {
        // mundur dikit pas kena peluru buat menghindar
        SetBack(30);
    }

    public override void OnHitWall(HitWallEvent e)
    {
        // mundur kalau nabrak tembok
        SetBack(40);
    }

    public override void OnHitBot(HitBotEvent e)
    {
        // kalau ditabrak bot lain, belok dikit
        if (e.IsRammed) TurnLeft(10);
    }

    private double CalcFirePower(double distance)
    {
        // kalau musuh dekat, pakai damage besar
        if (distance < 150) return 3;

        // jarak menengah
        if (distance < 400) return 2.5;

        // jarak jauh pakai power lebih hemat
        return 2;
    }

    private double ToRad(double degrees)
    {
        // konversi derajat ke radian
        return degrees * Math.PI / 180.0;
    }
}